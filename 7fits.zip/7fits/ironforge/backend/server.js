const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const mongoose = require('mongoose');

dotenv.config();

const app = express();

app.use(cors());
app.use(express.json());

app.use('/api/auth',      require('./routes/auth'));
app.use('/api/users',     require('./routes/users'));
app.use('/api/workouts',  require('./routes/workouts'));
app.use('/api/diet',      require('./routes/diet'));
app.use('/api/analytics', require('./routes/analytics'));
app.use('/api/plans',     require('./routes/plans'));
app.use('/api/trainers',  require('./routes/trainers'));
app.use('/api/admin',     require('./routes/admin'));

app.get('/api/health', (req, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 3001;
const MONGO_URI = process.env.MONGO_URI || '';

if (MONGO_URI) {
  mongoose.connect(MONGO_URI)
    .then(() => console.log('MongoDB connected'))
    .catch(err => console.error('MongoDB error:', err.message));
} else {
  console.log('No MONGO_URI set — running without database (mock data mode)');
}

app.listen(PORT, 'localhost', () => {
  console.log(`Backend running on port ${PORT}`);
});
