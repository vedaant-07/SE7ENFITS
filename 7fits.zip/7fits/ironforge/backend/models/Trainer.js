const mongoose = require('mongoose');

const trainerSchema = new mongoose.Schema({
  name:           { type: String, required: true },
  specialization: { type: String },
  experience:     { type: Number, default: 0 },
  certifications: [{ type: String }],
  bio:            { type: String },
  rating:         { type: Number, default: 5.0 },
  totalClients:   { type: Number, default: 0 },
  available:      { type: Boolean, default: true },
  user:           { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
}, { timestamps: true });

module.exports = mongoose.model('Trainer', trainerSchema);
