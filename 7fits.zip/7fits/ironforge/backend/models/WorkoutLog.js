const mongoose = require('mongoose');

const exerciseSchema = new mongoose.Schema({
  name:        { type: String, required: true },
  sets:        { type: Number },
  reps:        { type: Number },
  weight:      { type: Number },
  duration:    { type: Number },
  calories:    { type: Number, default: 0 },
});

const workoutLogSchema = new mongoose.Schema({
  user:          { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  muscleGroup:   { type: String },
  exercises:     [exerciseSchema],
  totalCalories: { type: Number, default: 0 },
  duration:      { type: Number },
  notes:         { type: String },
}, { timestamps: true });

module.exports = mongoose.model('WorkoutLog', workoutLogSchema);
