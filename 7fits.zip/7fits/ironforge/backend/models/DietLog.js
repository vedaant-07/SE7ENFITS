const mongoose = require('mongoose');

const foodItemSchema = new mongoose.Schema({
  name:     { type: String, required: true },
  calories: { type: Number, default: 0 },
  protein:  { type: Number, default: 0 },
  carbs:    { type: Number, default: 0 },
  fat:      { type: Number, default: 0 },
  quantity: { type: Number, default: 1 },
  unit:     { type: String, default: 'serving' },
});

const dietLogSchema = new mongoose.Schema({
  user:          { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  mealType:      { type: String, enum: ['breakfast', 'lunch', 'dinner', 'snack'], required: true },
  foods:         [foodItemSchema],
  totalCalories: { type: Number, default: 0 },
  totalProtein:  { type: Number, default: 0 },
  totalCarbs:    { type: Number, default: 0 },
  totalFat:      { type: Number, default: 0 },
  date:          { type: Date, default: Date.now },
}, { timestamps: true });

module.exports = mongoose.model('DietLog', dietLogSchema);
