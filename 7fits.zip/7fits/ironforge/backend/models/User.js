const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  name:        { type: String, required: true },
  email:       { type: String, required: true, unique: true, lowercase: true },
  password:    { type: String, required: true, select: false },
  role:        { type: String, enum: ['member', 'trainer', 'admin'], default: 'member' },
  plan:        { type: String, enum: ['none', 'monthly', 'quarterly', 'halfyearly', 'annual'], default: 'none' },
  planExpiry:  { type: Date },
  active:      { type: Boolean, default: true },
  streak:      { type: Number, default: 0 },
  lastWorkout: { type: Date },
  weight:      { type: Number },
  height:      { type: Number },
  goal:        { type: String },
}, { timestamps: true });

userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 10);
  next();
});

userSchema.methods.matchPassword = async function (plain) {
  return bcrypt.compare(plain, this.password);
};

module.exports = mongoose.model('User', userSchema);
