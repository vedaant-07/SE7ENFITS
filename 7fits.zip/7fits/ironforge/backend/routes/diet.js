const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const DietLog = require('../models/DietLog');

router.use(protect);

// GET /api/diet
router.get('/', async (req, res) => {
  try {
    const { date } = req.query;
    const query = { user: req.user.id };
    if (date) {
      const start = new Date(date); start.setHours(0,0,0,0);
      const end   = new Date(date); end.setHours(23,59,59,999);
      query.date  = { $gte: start, $lte: end };
    }
    const logs = await DietLog.find(query).sort({ createdAt: -1 });
    res.json({ success: true, logs });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// POST /api/diet
router.post('/', async (req, res) => {
  try {
    const { mealType, foods, totalCalories, totalProtein, totalCarbs, totalFat, date } = req.body;
    const log = await DietLog.create({ user: req.user.id, mealType, foods, totalCalories, totalProtein, totalCarbs, totalFat, date });
    res.status(201).json({ success: true, log });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// DELETE /api/diet/:id
router.delete('/:id', async (req, res) => {
  try {
    await DietLog.findOneAndDelete({ _id: req.params.id, user: req.user.id });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
