const express = require('express');
const router = express.Router();
const Trainer = require('../models/Trainer');

// GET /api/trainers
router.get('/', async (req, res) => {
  try {
    const trainers = await Trainer.find({ available: true });
    res.json({ success: true, trainers });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
