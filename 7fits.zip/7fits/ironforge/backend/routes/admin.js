const express = require('express');
const router = express.Router();
const { protect, adminOnly } = require('../middleware/auth');
const User = require('../models/User');
const WorkoutLog = require('../models/WorkoutLog');
const DietLog = require('../models/DietLog');
const Trainer = require('../models/Trainer');

// All admin routes are protected + admin only
router.use(protect, adminOnly);

// ── DASHBOARD STATS ────────────────────────────────────────────────
// GET /api/admin/stats
router.get('/stats', async (req, res) => {
  try {
    const totalUsers    = await User.countDocuments({ role: 'member' });
    const totalTrainers = await Trainer.countDocuments();
    const totalWorkouts = await WorkoutLog.countDocuments();

    // New users this week
    const weekAgo = new Date(); weekAgo.setDate(weekAgo.getDate() - 7);
    const newUsersThisWeek = await User.countDocuments({ role: 'member', createdAt: { $gte: weekAgo } });

    // Plan distribution
    const planDist = await User.aggregate([
      { $match: { role: 'member' } },
      { $group: { _id: '$plan', count: { $sum: 1 } } },
    ]);

    // Active members (worked out in last 7 days)
    const activeMembers = await User.countDocuments({ role: 'member', lastWorkout: { $gte: weekAgo } });

    // Revenue estimate
    const planPrices = { monthly: 150, quarterly: 400, halfyearly: 800, annual: 1500, none: 0 };
    const revenue = planDist.reduce((sum, p) => sum + (planPrices[p._id] || 0) * p.count, 0);

    res.json({
      success: true,
      stats: { totalUsers, totalTrainers, totalWorkouts, newUsersThisWeek, activeMembers, revenue, planDist },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ── USERS ──────────────────────────────────────────────────────────
// GET /api/admin/users
router.get('/users', async (req, res) => {
  try {
    const { search = '', plan = '', role = 'member', page = 1, limit = 20 } = req.query;
    const query = { role };
    if (search) query.$or = [
      { name: { $regex: search, $options: 'i' } },
      { email: { $regex: search, $options: 'i' } },
    ];
    if (plan) query.plan = plan;

    const users = await User.find(query)
      .select('-password')
      .sort({ createdAt: -1 })
      .skip((+page - 1) * +limit)
      .limit(+limit);
    const total = await User.countDocuments(query);

    res.json({ success: true, users, total, page: +page, pages: Math.ceil(total / +limit) });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// PUT /api/admin/users/:id  — update user plan / role / ban
router.put('/users/:id', async (req, res) => {
  try {
    const { plan, role, active, planExpiry } = req.body;
    const update = {};
    if (plan !== undefined)       update.plan       = plan;
    if (role !== undefined)       update.role       = role;
    if (active !== undefined)     update.active     = active;
    if (planExpiry !== undefined) update.planExpiry = planExpiry;

    const user = await User.findByIdAndUpdate(req.params.id, update, { new: true }).select('-password');
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });
    res.json({ success: true, user });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// DELETE /api/admin/users/:id
router.delete('/users/:id', async (req, res) => {
  try {
    await User.findByIdAndDelete(req.params.id);
    res.json({ success: true, message: 'User deleted' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ── TRAINERS ───────────────────────────────────────────────────────
// GET /api/admin/trainers
router.get('/trainers', async (req, res) => {
  try {
    const trainers = await Trainer.find().populate('user', 'name email');
    res.json({ success: true, trainers });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// POST /api/admin/trainers
router.post('/trainers', async (req, res) => {
  try {
    const { name, specialization, experience, certifications, bio } = req.body;
    const trainer = await Trainer.create({ name, specialization, experience, certifications, bio });
    res.status(201).json({ success: true, trainer });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// PUT /api/admin/trainers/:id
router.put('/trainers/:id', async (req, res) => {
  try {
    const trainer = await Trainer.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!trainer) return res.status(404).json({ success: false, message: 'Trainer not found' });
    res.json({ success: true, trainer });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// DELETE /api/admin/trainers/:id
router.delete('/trainers/:id', async (req, res) => {
  try {
    await Trainer.findByIdAndDelete(req.params.id);
    res.json({ success: true, message: 'Trainer deleted' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ── ACTIVITY FEED ──────────────────────────────────────────────────
// GET /api/admin/activity
router.get('/activity', async (req, res) => {
  try {
    const logs = await WorkoutLog.find()
      .populate('user', 'name email')
      .sort({ createdAt: -1 })
      .limit(30);
    res.json({ success: true, logs });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
