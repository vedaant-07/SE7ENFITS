const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const WorkoutLog = require('../models/WorkoutLog');
const User = require('../models/User');

router.use(protect);

// GET /api/workouts
router.get('/', async (req, res) => {
  try {
    const logs = await WorkoutLog.find({ user: req.user.id }).sort({ createdAt: -1 }).limit(50);
    res.json({ success: true, logs });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// POST /api/workouts
router.post('/', async (req, res) => {
  try {
    const { muscleGroup, exercises, totalCalories, duration, notes } = req.body;
    const log = await WorkoutLog.create({ user: req.user.id, muscleGroup, exercises, totalCalories, duration, notes });
    await User.findByIdAndUpdate(req.user.id, { lastWorkout: new Date(), $inc: { streak: 1 } });
    res.status(201).json({ success: true, log });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// DELETE /api/workouts/:id
router.delete('/:id', async (req, res) => {
  try {
    await WorkoutLog.findOneAndDelete({ _id: req.params.id, user: req.user.id });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
