const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const User = require('../models/User');

const PLANS = [
  { id: 'monthly',    name: 'Monthly',    price: 150,  duration: 30,  features: ['Unlimited workouts', 'Diet tracking', 'Analytics'] },
  { id: 'quarterly',  name: 'Quarterly',  price: 400,  duration: 90,  features: ['Unlimited workouts', 'Diet tracking', 'Analytics', 'Trainer access'] },
  { id: 'halfyearly', name: 'Half-Yearly', price: 800, duration: 180, features: ['Unlimited workouts', 'Diet tracking', 'Analytics', 'Trainer access', 'Priority support'] },
  { id: 'annual',     name: 'Annual',     price: 1500, duration: 365, features: ['All features', 'Dedicated trainer', 'Custom meal plans', 'Priority support'] },
];

// GET /api/plans
router.get('/', (req, res) => {
  res.json({ success: true, plans: PLANS });
});

// POST /api/plans/subscribe
router.post('/subscribe', protect, async (req, res) => {
  try {
    const { planId } = req.body;
    const plan = PLANS.find(p => p.id === planId);
    if (!plan) return res.status(400).json({ success: false, message: 'Invalid plan' });
    const expiry = new Date(); expiry.setDate(expiry.getDate() + plan.duration);
    const user = await User.findByIdAndUpdate(req.user.id, { plan: planId, planExpiry: expiry }, { new: true });
    res.json({ success: true, user });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
