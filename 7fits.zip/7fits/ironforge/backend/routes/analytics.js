const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const WorkoutLog = require('../models/WorkoutLog');
const DietLog = require('../models/DietLog');

router.use(protect);

// GET /api/analytics
router.get('/', async (req, res) => {
  try {
    const thirtyDaysAgo = new Date(); thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    const workouts = await WorkoutLog.find({ user: req.user.id, createdAt: { $gte: thirtyDaysAgo } }).sort({ createdAt: 1 });
    const diets    = await DietLog.find({ user: req.user.id, date: { $gte: thirtyDaysAgo } }).sort({ date: 1 });

    const totalCaloriesBurned = workouts.reduce((s, w) => s + (w.totalCalories || 0), 0);
    const totalCaloriesConsumed = diets.reduce((s, d) => s + (d.totalCalories || 0), 0);
    const workoutDays = [...new Set(workouts.map(w => w.createdAt.toDateString()))].length;

    const muscleGroupData = workouts.reduce((acc, w) => {
      if (w.muscleGroup) acc[w.muscleGroup] = (acc[w.muscleGroup] || 0) + 1;
      return acc;
    }, {});

    res.json({
      success: true,
      analytics: { totalCaloriesBurned, totalCaloriesConsumed, workoutDays, workoutCount: workouts.length, muscleGroupData },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
