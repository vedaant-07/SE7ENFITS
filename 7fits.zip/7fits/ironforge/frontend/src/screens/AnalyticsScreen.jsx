import React, { useState, useEffect } from 'react';
import api from '../api/client';

const MOCK_ANALYTICS = {
  totalCaloriesBurned: 4820,
  totalCaloriesConsumed: 42000,
  workoutDays: 18,
  workoutCount: 24,
  muscleGroupData: { Chest: 6, Back: 5, Legs: 5, Shoulders: 4, Arms: 4 },
};

const BAR_COLORS = ['var(--red)', 'var(--blue)', 'var(--green)', 'var(--amber)', '#a855f7'];

export default function AnalyticsScreen() {
  const [data, setData]       = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/analytics')
      .then(r => setData(r.data.analytics))
      .catch(() => setData(MOCK_ANALYTICS))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return (
    <div style={{ display: 'flex', justifyContent: 'center', paddingTop: 80 }}>
      <div className="spinner" />
    </div>
  );

  const mgEntries = Object.entries(data?.muscleGroupData || {}).sort((a, b) => b[1] - a[1]);
  const maxMg     = Math.max(...mgEntries.map(e => e[1]), 1);

  return (
    <div className="fade-up" style={{ padding: '20px 20px 0' }}>
      <div style={{ fontFamily: 'var(--font-display)', fontSize: 28, letterSpacing: '0.04em', marginBottom: 20 }}>
        ANA<span style={{ color: 'var(--blue)' }}>LYTICS</span>
      </div>

      {/* Stats grid */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 20 }}>
        {[
          { icon: '🔥', value: data?.totalCaloriesBurned?.toLocaleString(), label: 'Cal Burned', sub: 'Last 30 days', color: 'var(--red)' },
          { icon: '💪', value: data?.workoutCount, label: 'Workouts', sub: 'Last 30 days', color: 'var(--blue)' },
          { icon: '📅', value: data?.workoutDays, label: 'Active Days', sub: 'Last 30 days', color: 'var(--green)' },
          { icon: '🍽️', value: data?.totalCaloriesConsumed?.toLocaleString(), label: 'Cal Consumed', sub: 'Last 30 days', color: 'var(--amber)' },
        ].map((s, i) => (
          <div key={i} style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 14, padding: '14px 16px', position: 'relative', overflow: 'hidden' }}>
            <div style={{ position: 'absolute', top: 0, left: 0, width: 3, height: '100%', background: s.color }} />
            <div style={{ fontSize: 20, marginBottom: 6 }}>{s.icon}</div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 26, letterSpacing: '0.02em', color: s.color, lineHeight: 1 }}>{s.value}</div>
            <div style={{ fontSize: 10, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.1em', color: 'var(--white)', marginTop: 4 }}>{s.label}</div>
            <div style={{ fontSize: 10, color: 'var(--muted)', marginTop: 2 }}>{s.sub}</div>
          </div>
        ))}
      </div>

      {/* Muscle group chart */}
      {mgEntries.length > 0 && (
        <div style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 16, padding: '16px', marginBottom: 20 }}>
          <div style={{ fontSize: 11, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.12em', color: 'var(--muted2)', marginBottom: 14 }}>
            Muscle Groups Trained
          </div>
          {mgEntries.map(([mg, count], i) => (
            <div key={mg} style={{ marginBottom: 12 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, marginBottom: 5 }}>
                <span style={{ color: 'var(--white)', fontWeight: 600 }}>{mg}</span>
                <span style={{ color: 'var(--muted)' }}>{count} sessions</span>
              </div>
              <div style={{ height: 6, background: 'var(--border)', borderRadius: 3, overflow: 'hidden' }}>
                <div style={{
                  height: '100%',
                  width: `${(count / maxMg) * 100}%`,
                  background: BAR_COLORS[i % BAR_COLORS.length],
                  borderRadius: 3,
                  transition: 'width 0.8s',
                }} />
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Calorie balance */}
      <div style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 16, padding: '16px', marginBottom: 20 }}>
        <div style={{ fontSize: 11, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.12em', color: 'var(--muted2)', marginBottom: 12 }}>
          Calorie Balance (30 days)
        </div>
        <div style={{ display: 'flex', gap: 16 }}>
          {[
            { label: 'Consumed', value: data?.totalCaloriesConsumed, color: 'var(--amber)' },
            { label: 'Burned',   value: data?.totalCaloriesBurned,   color: 'var(--red)' },
          ].map(({ label, value, color }) => (
            <div key={label} style={{ flex: 1 }}>
              <div style={{ fontSize: 10, color: 'var(--muted)', marginBottom: 4 }}>{label}</div>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 22, color, letterSpacing: '0.02em' }}>
                {value?.toLocaleString()}
              </div>
              <div style={{ fontSize: 9, color: 'var(--muted2)', marginTop: 2 }}>kcal</div>
            </div>
          ))}
        </div>
        <div style={{ height: 1, background: 'var(--border)', margin: '12px 0' }} />
        <div style={{ fontSize: 12, color: 'var(--muted2)' }}>
          Net: <span style={{ color: (data?.totalCaloriesConsumed - data?.totalCaloriesBurned) > 0 ? 'var(--amber)' : 'var(--green)', fontWeight: 700 }}>
            {((data?.totalCaloriesConsumed || 0) - (data?.totalCaloriesBurned || 0)).toLocaleString()} kcal surplus
          </span>
        </div>
      </div>
    </div>
  );
}
