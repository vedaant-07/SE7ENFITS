import React, { useState, useEffect } from 'react';
import api from '../api/client';
import Toast from '../components/Toast';

const MEAL_TYPES = ['breakfast', 'lunch', 'dinner', 'snack'];
const MEAL_ICONS = { breakfast: '🌅', lunch: '☀️', dinner: '🌙', snack: '🍎' };

const FOOD_PRESETS = [
  { name: 'Chicken Breast (100g)', calories: 165, protein: 31, carbs: 0, fat: 3.6, quantity: 1, unit: '100g' },
  { name: 'Brown Rice (1 cup)', calories: 216, protein: 5, carbs: 44, fat: 1.8, quantity: 1, unit: 'cup' },
  { name: 'Egg (1 large)', calories: 72, protein: 6, carbs: 0.4, fat: 5, quantity: 1, unit: 'egg' },
  { name: 'Banana', calories: 89, protein: 1.1, carbs: 23, fat: 0.3, quantity: 1, unit: 'medium' },
  { name: 'Paneer (100g)', calories: 265, protein: 18, carbs: 3, fat: 20, quantity: 1, unit: '100g' },
  { name: 'Oats (50g)', calories: 187, protein: 6.5, carbs: 31, fat: 3.5, quantity: 1, unit: '50g' },
  { name: 'Almonds (30g)', calories: 174, protein: 6, carbs: 6, fat: 15, quantity: 1, unit: '30g' },
  { name: 'Whole Milk (200ml)', calories: 122, protein: 6.5, carbs: 9.5, fat: 6.5, quantity: 1, unit: '200ml' },
];

const MOCK_LOGS = [
  { _id: '1', mealType: 'breakfast', foods: [{ name: 'Oats', calories: 187, protein: 6.5, carbs: 31, fat: 3.5 }], totalCalories: 187, totalProtein: 6.5, createdAt: new Date().toISOString() },
  { _id: '2', mealType: 'lunch',     foods: [{ name: 'Chicken Breast', calories: 165, protein: 31, carbs: 0, fat: 3.6 }, { name: 'Brown Rice', calories: 216, protein: 5, carbs: 44, fat: 1.8 }], totalCalories: 381, totalProtein: 36, createdAt: new Date().toISOString() },
];

export default function DietScreen() {
  const [logs, setLogs]           = useState([]);
  const [adding, setAdding]       = useState(false);
  const [mealType, setMealType]   = useState('breakfast');
  const [foods, setFoods]         = useState([]);
  const [selected, setSelected]   = useState(null);
  const [loading, setLoading]     = useState(true);
  const [saving, setSaving]       = useState(false);
  const [toast, setToast]         = useState(null);

  useEffect(() => {
    const today = new Date().toISOString().split('T')[0];
    api.get('/diet', { params: { date: today } })
      .then(r => setLogs(r.data.logs))
      .catch(() => setLogs(MOCK_LOGS))
      .finally(() => setLoading(false));
  }, []);

  const toggleFood = (food) => {
    setFoods(f => {
      const exists = f.find(x => x.name === food.name);
      return exists ? f.filter(x => x.name !== food.name) : [...f, { ...food }];
    });
  };

  const saveMeal = async () => {
    if (foods.length === 0) { setToast({ message: 'Select at least one food', type: 'error' }); return; }
    setSaving(true);
    const totalCalories = foods.reduce((s, f) => s + f.calories, 0);
    const totalProtein  = foods.reduce((s, f) => s + (f.protein || 0), 0);
    const totalCarbs    = foods.reduce((s, f) => s + (f.carbs || 0), 0);
    const totalFat      = foods.reduce((s, f) => s + (f.fat || 0), 0);
    const payload = { mealType, foods, totalCalories, totalProtein, totalCarbs, totalFat, date: new Date().toISOString() };
    try {
      const r = await api.post('/diet', payload);
      setLogs(l => [r.data.log, ...l]);
    } catch {
      setLogs(l => [{ _id: Date.now().toString(), mealType, foods, totalCalories, totalProtein, createdAt: new Date().toISOString() }, ...l]);
    }
    setAdding(false); setFoods([]); setSelected(null);
    setToast({ message: 'Meal logged!' });
    setSaving(false);
  };

  const totalCals = logs.reduce((s, l) => s + (l.totalCalories || 0), 0);
  const totalProt = logs.reduce((s, l) => s + (l.totalProtein || 0), 0);

  return (
    <div className="fade-up" style={{ padding: '20px 20px 0' }}>
      {toast && <Toast {...toast} onClose={() => setToast(null)} />}

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: 28, letterSpacing: '0.04em' }}>
          DI<span style={{ color: 'var(--green)' }}>ET</span>
        </div>
        <button className="btn btn-primary" onClick={() => setAdding(!adding)}
          style={{ width: 'auto', padding: '8px 16px', fontSize: 12 }}>
          {adding ? 'Cancel' : '+ Log Meal'}
        </button>
      </div>

      {/* Today summary */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 20 }}>
        <div style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 12, padding: '12px 14px' }}>
          <div style={{ fontSize: 10, color: 'var(--muted2)', marginBottom: 4 }}>TODAY'S CALORIES</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 26, color: 'var(--amber)', letterSpacing: '0.02em' }}>
            {totalCals}
          </div>
          <div style={{ fontSize: 10, color: 'var(--muted)', marginTop: 2 }}>/ 2000 goal</div>
        </div>
        <div style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 12, padding: '12px 14px' }}>
          <div style={{ fontSize: 10, color: 'var(--muted2)', marginBottom: 4 }}>PROTEIN</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 26, color: 'var(--green)', letterSpacing: '0.02em' }}>
            {Math.round(totalProt)}g
          </div>
          <div style={{ fontSize: 10, color: 'var(--muted)', marginTop: 2 }}>/ 150g goal</div>
        </div>
      </div>

      {adding && (
        <div style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 16, padding: 16, marginBottom: 20 }}>
          <div style={{ display: 'flex', gap: 6, marginBottom: 14 }}>
            {MEAL_TYPES.map(m => (
              <button key={m} onClick={() => setMealType(m)} style={{
                flex: 1, padding: '8px 0', borderRadius: 8, border: `1px solid ${mealType === m ? 'var(--green)' : 'var(--border)'}`,
                background: mealType === m ? 'rgba(34,197,94,0.1)' : 'var(--surface)',
                color: mealType === m ? 'var(--green)' : 'var(--muted)',
                fontSize: 16, cursor: 'pointer', fontFamily: 'var(--font-body)',
              }}>{MEAL_ICONS[m]}</button>
            ))}
          </div>

          <div style={{ fontSize: 11, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.12em', color: 'var(--muted2)', marginBottom: 10 }}>
            Select Foods
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 14 }}>
            {FOOD_PRESETS.map(food => {
              const picked = foods.find(f => f.name === food.name);
              return (
                <div key={food.name} onClick={() => toggleFood(food)} style={{
                  background: picked ? 'rgba(34,197,94,0.08)' : 'var(--surface)',
                  border: `1px solid ${picked ? 'rgba(34,197,94,0.4)' : 'var(--border)'}`,
                  borderRadius: 10, padding: '10px 12px', cursor: 'pointer',
                  display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                  transition: 'all 0.15s',
                }}>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 600, color: picked ? 'var(--green)' : 'var(--white)' }}>{food.name}</div>
                    <div style={{ fontSize: 10, color: 'var(--muted)', marginTop: 2 }}>
                      P: {food.protein}g · C: {food.carbs}g · F: {food.fat}g
                    </div>
                  </div>
                  <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--amber)' }}>{food.calories} cal</div>
                </div>
              );
            })}
          </div>
          {foods.length > 0 && (
            <div style={{ fontSize: 12, color: 'var(--muted2)', marginBottom: 10 }}>
              Selected: {foods.length} item{foods.length !== 1 ? 's' : ''} · {foods.reduce((s,f)=>s+f.calories,0)} cal
            </div>
          )}
          <button onClick={saveMeal} className="btn btn-primary" disabled={saving} style={{ fontSize: 13 }}>
            {saving ? 'Saving...' : `Log ${mealType.charAt(0).toUpperCase() + mealType.slice(1)}`}
          </button>
        </div>
      )}

      {loading ? (
        <div style={{ display: 'flex', justifyContent: 'center', paddingTop: 40 }}><div className="spinner" /></div>
      ) : logs.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '40px 0', color: 'var(--muted)' }}>
          <div style={{ fontSize: 40, marginBottom: 12 }}>🥗</div>
          <div style={{ fontSize: 14 }}>No meals logged today.</div>
        </div>
      ) : (
        logs.map(log => (
          <div key={log._id} style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 14, padding: '14px 16px', marginBottom: 12 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
              <span style={{ fontSize: 18 }}>{MEAL_ICONS[log.mealType]}</span>
              <div style={{ fontWeight: 700, fontSize: 13, textTransform: 'capitalize' }}>{log.mealType}</div>
              <div style={{ marginLeft: 'auto', fontSize: 11, color: 'var(--amber)' }}>{log.totalCalories} cal</div>
            </div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5 }}>
              {(log.foods || []).map((f, i) => (
                <span key={i} style={{ fontSize: 10, background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 5, padding: '2px 7px', color: 'var(--muted2)' }}>
                  {f.name}
                </span>
              ))}
            </div>
          </div>
        ))
      )}
    </div>
  );
}
