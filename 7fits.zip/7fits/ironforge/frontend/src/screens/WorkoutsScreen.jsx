import React, { useState, useEffect } from 'react';
import api from '../api/client';
import Toast from '../components/Toast';

const MUSCLE_GROUPS = ['Chest', 'Back', 'Legs', 'Shoulders', 'Arms', 'Core', 'Full Body', 'Cardio'];

const PRESET_EXERCISES = {
  Chest:      ['Bench Press', 'Push-Up', 'Incline Press', 'Cable Fly', 'Dips'],
  Back:       ['Deadlift', 'Pull-Up', 'Bent-Over Row', 'Lat Pulldown', 'Cable Row'],
  Legs:       ['Squat', 'Leg Press', 'Romanian Deadlift', 'Lunges', 'Leg Curl'],
  Shoulders:  ['Overhead Press', 'Lateral Raise', 'Front Raise', 'Face Pull', 'Shrugs'],
  Arms:       ['Bicep Curl', 'Tricep Pushdown', 'Hammer Curl', 'Skull Crusher', 'Preacher Curl'],
  Core:       ['Plank', 'Crunches', 'Leg Raise', 'Russian Twist', 'Ab Wheel'],
  'Full Body': ['Burpees', 'Clean & Press', 'Thrusters', 'Kettlebell Swing'],
  Cardio:     ['Treadmill', 'Cycling', 'Jump Rope', 'Rowing', 'Stair Climber'],
};

const MOCK_LOGS = [
  { _id: '1', muscleGroup: 'Chest', exercises: [{ name: 'Bench Press', sets: 4, reps: 10, weight: 80 }], totalCalories: 320, createdAt: new Date().toISOString() },
  { _id: '2', muscleGroup: 'Back',  exercises: [{ name: 'Deadlift', sets: 3, reps: 8, weight: 120 }],  totalCalories: 410, createdAt: new Date(Date.now() - 86400000).toISOString() },
];

export default function WorkoutsScreen() {
  const [logs, setLogs]         = useState([]);
  const [adding, setAdding]     = useState(false);
  const [muscleGroup, setMG]    = useState('Chest');
  const [exercises, setExs]     = useState([{ name: '', sets: 3, reps: 10, weight: 0, calories: 50 }]);
  const [loading, setLoading]   = useState(true);
  const [saving, setSaving]     = useState(false);
  const [toast, setToast]       = useState(null);

  useEffect(() => {
    api.get('/workouts')
      .then(r => setLogs(r.data.logs))
      .catch(() => setLogs(MOCK_LOGS))
      .finally(() => setLoading(false));
  }, []);

  const addExercise = () => setExs(e => [...e, { name: '', sets: 3, reps: 10, weight: 0, calories: 50 }]);
  const removeExercise = (i) => setExs(e => e.filter((_, idx) => idx !== i));
  const updateExercise = (i, key, val) => setExs(e => e.map((ex, idx) => idx === i ? { ...ex, [key]: val } : ex));

  const saveWorkout = async () => {
    if (!exercises[0].name) { setToast({ message: 'Add at least one exercise', type: 'error' }); return; }
    setSaving(true);
    const totalCalories = exercises.reduce((s, e) => s + (Number(e.calories) || 0), 0);
    const payload = { muscleGroup, exercises, totalCalories };
    try {
      const r = await api.post('/workouts', payload);
      setLogs(l => [r.data.log, ...l]);
    } catch {
      setLogs(l => [{ _id: Date.now().toString(), muscleGroup, exercises, totalCalories, createdAt: new Date().toISOString() }, ...l]);
    }
    setAdding(false);
    setExs([{ name: '', sets: 3, reps: 10, weight: 0, calories: 50 }]);
    setToast({ message: 'Workout logged!' });
    setSaving(false);
  };

  return (
    <div className="fade-up" style={{ padding: '20px 20px 0' }}>
      {toast && <Toast {...toast} onClose={() => setToast(null)} />}

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: 28, letterSpacing: '0.04em' }}>
          WORK<span style={{ color: 'var(--red)' }}>OUTS</span>
        </div>
        <button className="btn btn-primary" onClick={() => setAdding(!adding)}
          style={{ width: 'auto', padding: '8px 16px', fontSize: 12 }}>
          {adding ? 'Cancel' : '+ Log'}
        </button>
      </div>

      {adding && (
        <div style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 16, padding: 16, marginBottom: 20 }}>
          <div style={{ fontSize: 11, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.12em', color: 'var(--muted2)', marginBottom: 10 }}>
            Muscle Group
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 16 }}>
            {MUSCLE_GROUPS.map(mg => (
              <button key={mg} onClick={() => setMG(mg)} style={{
                padding: '6px 12px', borderRadius: 8, border: `1px solid ${muscleGroup === mg ? 'var(--red)' : 'var(--border)'}`,
                background: muscleGroup === mg ? 'var(--red-soft)' : 'var(--surface)',
                color: muscleGroup === mg ? 'var(--red)' : 'var(--muted)',
                fontSize: 11, fontWeight: 700, cursor: 'pointer', fontFamily: 'var(--font-body)',
                transition: 'all 0.15s',
              }}>{mg}</button>
            ))}
          </div>

          <div style={{ fontSize: 11, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.12em', color: 'var(--muted2)', marginBottom: 10 }}>
            Exercises
          </div>

          {exercises.map((ex, i) => (
            <div key={i} style={{ background: 'var(--surface)', borderRadius: 12, padding: 12, marginBottom: 8, border: '1px solid var(--border)' }}>
              <div style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
                <select value={ex.name} onChange={e => updateExercise(i, 'name', e.target.value)} style={{
                  flex: 1, background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 8,
                  color: ex.name ? 'var(--white)' : 'var(--muted)', fontSize: 12, padding: '8px 10px',
                  fontFamily: 'var(--font-body)', outline: 'none',
                }}>
                  <option value="">Select exercise...</option>
                  {(PRESET_EXERCISES[muscleGroup] || []).map(e => <option key={e} value={e}>{e}</option>)}
                </select>
                {exercises.length > 1 && (
                  <button onClick={() => removeExercise(i)} style={{
                    background: 'rgba(255,45,58,0.1)', border: '1px solid rgba(255,45,58,0.3)',
                    borderRadius: 8, padding: '6px 10px', cursor: 'pointer', color: 'var(--red)', fontSize: 12,
                  }}>✕</button>
                )}
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', gap: 6 }}>
                {[['sets','Sets'],['reps','Reps'],['weight','kg'],['calories','Cal']].map(([k, label]) => (
                  <div key={k}>
                    <div style={{ fontSize: 9, color: 'var(--muted)', marginBottom: 3 }}>{label}</div>
                    <input type="number" value={ex[k]} onChange={e => updateExercise(i, k, e.target.value)}
                      style={{ width: '100%', background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 6,
                        color: 'var(--white)', fontSize: 12, padding: '6px 8px', fontFamily: 'var(--font-body)', outline: 'none' }} />
                  </div>
                ))}
              </div>
            </div>
          ))}

          <button onClick={addExercise} className="btn btn-secondary" style={{ marginBottom: 10, fontSize: 12 }}>
            + Add Exercise
          </button>
          <button onClick={saveWorkout} className="btn btn-primary" disabled={saving} style={{ fontSize: 13 }}>
            {saving ? 'Saving...' : 'Save Workout'}
          </button>
        </div>
      )}

      {loading ? (
        <div style={{ display: 'flex', justifyContent: 'center', paddingTop: 40 }}><div className="spinner" /></div>
      ) : logs.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '40px 0', color: 'var(--muted)' }}>
          <div style={{ fontSize: 40, marginBottom: 12 }}>💪</div>
          <div style={{ fontSize: 14 }}>No workouts logged yet.</div>
          <div style={{ fontSize: 12, marginTop: 6 }}>Tap "+ Log" to start tracking.</div>
        </div>
      ) : (
        logs.map(log => (
          <div key={log._id} style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 14, padding: '14px 16px', marginBottom: 12 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 18, letterSpacing: '0.04em', color: 'var(--red)' }}>
                {log.muscleGroup}
              </div>
              <div style={{ fontSize: 10, color: 'var(--muted)' }}>
                {new Date(log.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}
              </div>
            </div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 6 }}>
              {(log.exercises || []).map((ex, i) => (
                <span key={i} style={{ fontSize: 11, background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 6, padding: '3px 8px', color: 'var(--muted2)' }}>
                  {ex.name} {ex.sets && ex.reps ? `${ex.sets}×${ex.reps}` : ''}{ex.weight ? ` @ ${ex.weight}kg` : ''}
                </span>
              ))}
            </div>
            {log.totalCalories > 0 && (
              <div style={{ fontSize: 11, color: 'var(--amber)' }}>🔥 {log.totalCalories} cal burned</div>
            )}
          </div>
        ))
      )}
    </div>
  );
}
