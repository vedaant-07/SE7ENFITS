import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';

export default function AuthScreen() {
  const { login, register, demoLogin } = useAuth();
  const [mode, setMode]       = useState('login');
  const [name, setName]       = useState('');
  const [email, setEmail]     = useState('');
  const [password, setPass]   = useState('');
  const [error, setError]     = useState('');
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      if (mode === 'login') {
        await login(email, password);
      } else {
        if (!name.trim()) { setError('Name is required'); setLoading(false); return; }
        await register(name, email, password);
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Something went wrong');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fade-up" style={{ flex: 1, display: 'flex', flexDirection: 'column', padding: '40px 28px 32px' }}>
      {/* Logo */}
      <div style={{ marginBottom: 48, textAlign: 'center' }}>
        <div style={{
          fontFamily: 'var(--font-display)',
          fontSize: 56,
          letterSpacing: '0.08em',
          lineHeight: 1,
          color: 'var(--white)',
        }}>
          SE<span style={{ color: 'var(--red)' }}>7</span>EN
        </div>
        <div style={{
          fontFamily: 'var(--font-display)',
          fontSize: 22,
          letterSpacing: '0.5em',
          color: 'var(--muted2)',
          marginTop: 2,
        }}>FIT</div>
        <div style={{ width: 40, height: 2, background: 'var(--red)', margin: '12px auto 0' }} />
      </div>

      {/* Mode toggle */}
      <div style={{ display: 'flex', background: 'var(--surface)', borderRadius: 12, padding: 4, marginBottom: 28, border: '1px solid var(--border)' }}>
        {['login', 'register'].map(m => (
          <button key={m} onClick={() => { setMode(m); setError(''); }} style={{
            flex: 1, padding: '10px 0', borderRadius: 9, border: 'none',
            background: mode === m ? 'var(--red)' : 'transparent',
            color: mode === m ? '#fff' : 'var(--muted)',
            fontFamily: 'var(--font-body)', fontSize: 13, fontWeight: 700,
            cursor: 'pointer', textTransform: 'capitalize', transition: 'all 0.2s',
          }}>{m === 'login' ? 'Sign In' : 'Sign Up'}</button>
        ))}
      </div>

      <form onSubmit={submit} style={{ display: 'flex', flexDirection: 'column', gap: 12, flex: 1 }}>
        {mode === 'register' && (
          <input
            className="input-field"
            placeholder="Full name"
            value={name}
            onChange={e => setName(e.target.value)}
            required
          />
        )}
        <input
          className="input-field"
          type="email"
          placeholder="Email address"
          value={email}
          onChange={e => setEmail(e.target.value)}
          required
        />
        <input
          className="input-field"
          type="password"
          placeholder="Password"
          value={password}
          onChange={e => setPass(e.target.value)}
          required
          minLength={6}
        />

        {error && (
          <div style={{ fontSize: 12, color: 'var(--red)', textAlign: 'center', padding: '6px 0' }}>
            {error}
          </div>
        )}

        <button className="btn btn-primary" type="submit" disabled={loading} style={{ marginTop: 8 }}>
          {loading ? '...' : mode === 'login' ? 'Sign In' : 'Create Account'}
        </button>
      </form>

      <div style={{ margin: '20px 0 8px', display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{ flex: 1, height: 1, background: 'var(--border)' }} />
        <span style={{ fontSize: 10, color: 'var(--muted)', fontWeight: 700, letterSpacing: '0.1em' }}>TRY DEMO</span>
        <div style={{ flex: 1, height: 1, background: 'var(--border)' }} />
      </div>

      <div style={{ display: 'flex', gap: 10 }}>
        <button onClick={() => demoLogin('member')} style={{
          flex: 1, padding: '11px 0', borderRadius: 12, border: '1px solid var(--border)',
          background: 'var(--surface)', color: 'var(--white)',
          fontFamily: 'var(--font-body)', fontSize: 12, fontWeight: 700, cursor: 'pointer',
        }}>
          💪 Member Demo
        </button>
        <button onClick={() => demoLogin('admin')} style={{
          flex: 1, padding: '11px 0', borderRadius: 12, border: '1px solid var(--border)',
          background: 'var(--surface)', color: 'var(--white)',
          fontFamily: 'var(--font-body)', fontSize: 12, fontWeight: 700, cursor: 'pointer',
        }}>
          🛡️ Admin Demo
        </button>
      </div>

      <div style={{ textAlign: 'center', marginTop: 16, fontSize: 11, color: 'var(--muted)' }}>
        SE7EN FIT · Forge Your Legacy
      </div>
    </div>
  );
}
