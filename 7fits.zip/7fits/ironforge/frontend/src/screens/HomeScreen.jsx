import React from 'react';
import { useAuth } from '../context/AuthContext';

const QUICK_ACTIONS = [
  { icon: '💪', label: 'Log Workout', tab: 'workouts', color: 'var(--red)' },
  { icon: '🥗', label: 'Log Meal',    tab: 'diet',     color: 'var(--green)' },
  { icon: '📊', label: 'My Stats',    tab: 'analytics', color: 'var(--blue)' },
  { icon: '⭐', label: 'Upgrade',     tab: 'plans',    color: 'var(--amber)' },
];

const TIPS = [
  'Progressive overload is key — increase weight or reps each week.',
  'Rest 48h before training the same muscle group again.',
  'Protein goal: 1.6–2.2g per kg of bodyweight.',
  'Compound lifts build the most overall muscle mass.',
  'Sleep 7–9h for optimal recovery and growth.',
  'Track your workouts to measure real progress.',
];

export default function HomeScreen({ setActiveTab }) {
  const { user, logout } = useAuth();
  const greeting = () => {
    const h = new Date().getHours();
    if (h < 12) return 'Good Morning';
    if (h < 17) return 'Good Afternoon';
    return 'Good Evening';
  };

  const tip = TIPS[Math.floor(Date.now() / 86400000) % TIPS.length];

  return (
    <div className="fade-up" style={{ padding: '20px 20px 0' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 24 }}>
        <div>
          <div style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 2 }}>{greeting()},</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 30, letterSpacing: '0.04em', lineHeight: 1 }}>
            {user?.name?.split(' ')[0]?.toUpperCase()}
          </div>
        </div>
        <button onClick={logout} style={{
          background: 'var(--surface)', border: '1px solid var(--border)',
          color: 'var(--muted)', fontSize: 11, fontWeight: 700,
          padding: '7px 12px', borderRadius: 8, cursor: 'pointer',
          fontFamily: 'var(--font-body)',
        }}>Sign Out</button>
      </div>

      {/* Plan banner */}
      <div style={{
        background: user?.plan && user.plan !== 'none'
          ? 'linear-gradient(135deg, rgba(255,45,58,0.2), rgba(255,45,58,0.06))'
          : 'var(--surface)',
        border: `1px solid ${user?.plan && user.plan !== 'none' ? 'rgba(255,45,58,0.4)' : 'var(--border)'}`,
        borderRadius: 16,
        padding: '16px 18px',
        marginBottom: 20,
        display: 'flex',
        alignItems: 'center',
        gap: 14,
      }}>
        <span style={{ fontSize: 32 }}>{user?.plan && user.plan !== 'none' ? '🔥' : '🎯'}</span>
        <div>
          <div style={{ fontSize: 13, fontWeight: 700 }}>
            {user?.plan && user.plan !== 'none'
              ? `${user.plan.charAt(0).toUpperCase() + user.plan.slice(1)} Plan Active`
              : 'No Active Plan'}
          </div>
          <div style={{ fontSize: 11, color: 'var(--muted2)', marginTop: 2 }}>
            {user?.plan && user.plan !== 'none'
              ? 'Keep crushing your goals!'
              : 'Upgrade to unlock all features'}
          </div>
        </div>
      </div>

      {/* Quick actions */}
      <div style={{ marginBottom: 20 }}>
        <div style={{ fontSize: 11, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.12em', color: 'var(--muted2)', marginBottom: 12 }}>
          Quick Actions
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          {QUICK_ACTIONS.map(a => (
            <button key={a.tab} onClick={() => setActiveTab(a.tab)} style={{
              background: 'var(--card)',
              border: '1px solid var(--border)',
              borderRadius: 14,
              padding: '16px 14px',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: 10,
              fontFamily: 'var(--font-body)',
              color: 'var(--white)',
              fontSize: 13,
              fontWeight: 700,
              textAlign: 'left',
              transition: 'border-color 0.15s',
            }}
              onMouseEnter={e => e.currentTarget.style.borderColor = a.color}
              onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--border)'}
            >
              <span style={{ fontSize: 22 }}>{a.icon}</span>
              <span>{a.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Daily tip */}
      <div style={{
        background: 'var(--card)',
        border: '1px solid var(--border)',
        borderRadius: 16,
        padding: '16px 18px',
        marginBottom: 20,
      }}>
        <div style={{ fontSize: 10, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.12em', color: 'var(--red)', marginBottom: 8 }}>
          Daily Tip
        </div>
        <div style={{ fontSize: 13, color: 'var(--muted2)', lineHeight: 1.6 }}>{tip}</div>
      </div>

      {/* Streak */}
      {user?.streak > 0 && (
        <div style={{
          background: 'linear-gradient(135deg, rgba(245,158,11,0.15), rgba(245,158,11,0.04))',
          border: '1px solid rgba(245,158,11,0.3)',
          borderRadius: 16,
          padding: '14px 18px',
          display: 'flex',
          alignItems: 'center',
          gap: 12,
          marginBottom: 20,
        }}>
          <span style={{ fontSize: 28 }}>🔥</span>
          <div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 24, color: 'var(--amber)', letterSpacing: '0.04em' }}>
              {user.streak} DAY STREAK
            </div>
            <div style={{ fontSize: 11, color: 'var(--muted2)', marginTop: 2 }}>Keep it going!</div>
          </div>
        </div>
      )}
    </div>
  );
}
