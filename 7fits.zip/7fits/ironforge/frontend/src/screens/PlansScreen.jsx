import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import api from '../api/client';
import Toast from '../components/Toast';

const FALLBACK_PLANS = [
  { id: 'monthly',    name: 'Monthly',     price: 150,  duration: 30,  features: ['Unlimited workouts', 'Diet tracking', 'Analytics'] },
  { id: 'quarterly',  name: 'Quarterly',   price: 400,  duration: 90,  features: ['Unlimited workouts', 'Diet tracking', 'Analytics', 'Trainer access'] },
  { id: 'halfyearly', name: 'Half-Yearly', price: 800,  duration: 180, features: ['Unlimited workouts', 'Diet tracking', 'Analytics', 'Trainer access', 'Priority support'] },
  { id: 'annual',     name: 'Annual',      price: 1500, duration: 365, features: ['All features', 'Dedicated trainer', 'Custom meal plans', 'Priority support'] },
];

const PLAN_COLORS = { monthly: 'var(--blue)', quarterly: 'var(--amber)', halfyearly: 'var(--red)', annual: '#c9a84c' };

export default function PlansScreen() {
  const { user } = useAuth();
  const [plans, setPlans]   = useState(FALLBACK_PLANS);
  const [loading, setLoading] = useState(false);
  const [toast, setToast]   = useState(null);

  useEffect(() => {
    api.get('/plans')
      .then(r => setPlans(r.data.plans))
      .catch(() => {});
  }, []);

  const subscribe = async (planId) => {
    setLoading(true);
    try {
      await api.post('/plans/subscribe', { planId });
      setToast({ message: 'Plan activated!' });
    } catch {
      setToast({ message: 'Plan selected (demo mode)!' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fade-up" style={{ padding: '20px 20px 0' }}>
      {toast && <Toast {...toast} onClose={() => setToast(null)} />}

      <div style={{ fontFamily: 'var(--font-display)', fontSize: 28, letterSpacing: '0.04em', marginBottom: 6 }}>
        MEM<span style={{ color: 'var(--amber)' }}>BERSHIP</span>
      </div>
      <div style={{ fontSize: 12, color: 'var(--muted2)', marginBottom: 20 }}>
        Forge your legacy. Choose your path.
      </div>

      {user?.plan && user.plan !== 'none' && (
        <div style={{
          background: 'linear-gradient(135deg, rgba(255,45,58,0.18), rgba(255,45,58,0.05))',
          border: '1px solid rgba(255,45,58,0.35)',
          borderRadius: 14, padding: '14px 16px', marginBottom: 20,
          display: 'flex', alignItems: 'center', gap: 12,
        }}>
          <span style={{ fontSize: 24 }}>✅</span>
          <div>
            <div style={{ fontSize: 13, fontWeight: 700 }}>
              Current: {user.plan.charAt(0).toUpperCase() + user.plan.slice(1)} Plan
            </div>
            <div style={{ fontSize: 11, color: 'var(--muted2)', marginTop: 2 }}>Your membership is active</div>
          </div>
        </div>
      )}

      {plans.map(plan => {
        const color   = PLAN_COLORS[plan.id] || 'var(--red)';
        const current = user?.plan === plan.id;
        return (
          <div key={plan.id} style={{
            background: current ? `linear-gradient(135deg, ${color}22, ${color}08)` : 'var(--card)',
            border: `1px solid ${current ? color + '55' : 'var(--border)'}`,
            borderRadius: 16, padding: '18px 18px', marginBottom: 14,
            position: 'relative', overflow: 'hidden',
          }}>
            {plan.id === 'annual' && (
              <div style={{ position: 'absolute', top: 12, right: 12, background: color, color: '#000', fontSize: 9, fontWeight: 800, padding: '3px 8px', borderRadius: 5, letterSpacing: '0.1em' }}>
                BEST VALUE
              </div>
            )}
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginBottom: 4 }}>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 22, letterSpacing: '0.04em', color }}>{plan.name}</div>
            </div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, marginBottom: 12 }}>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 36, color, letterSpacing: '0.02em' }}>₹{plan.price}</div>
              <div style={{ fontSize: 12, color: 'var(--muted)' }}>/ {plan.duration} days</div>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 14 }}>
              {plan.features.map(f => (
                <div key={f} style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, color: 'var(--muted2)' }}>
                  <span style={{ color, fontSize: 10 }}>✓</span> {f}
                </div>
              ))}
            </div>

            <button
              onClick={() => subscribe(plan.id)}
              disabled={loading || current}
              style={{
                width: '100%', padding: '12px 0', borderRadius: 10,
                background: current ? 'transparent' : color,
                color: current ? color : '#fff',
                fontFamily: 'var(--font-body)', fontSize: 13, fontWeight: 700,
                cursor: current ? 'default' : 'pointer',
                border: current ? `1px solid ${color}44` : '1px solid transparent',
                letterSpacing: '0.04em',
                opacity: loading ? 0.6 : 1,
              }}
            >
              {current ? 'Current Plan' : 'Subscribe'}
            </button>
          </div>
        );
      })}
    </div>
  );
}
