import React, { useState } from 'react';

const STATUS_COLORS = { active: 'var(--green)', maintenance: 'var(--amber)', out_of_service: 'var(--red)' };
const STATUS_LABELS = { active: 'Active', maintenance: 'Maintenance', out_of_service: 'Out of Service' };

const INIT_EQUIPMENT = [
  { id:1, name:'Treadmill #1',     category:'Cardio',    brand:'Life Fitness', purchased:'2023-06-01', lastService:'2026-03-10', nextService:'2026-06-10', status:'active',          usage: 92, notes:'Running smooth' },
  { id:2, name:'Treadmill #2',     category:'Cardio',    brand:'Precor',       purchased:'2023-06-01', lastService:'2026-01-14', nextService:'2026-04-14', status:'maintenance',     usage: 88, notes:'Belt worn, needs replacement' },
  { id:3, name:'Smith Machine',    category:'Strength',  brand:'Hammer',       purchased:'2022-11-01', lastService:'2026-04-02', nextService:'2026-07-02', status:'active',          usage: 78, notes:'Lubricated' },
  { id:4, name:'Cable Crossover',  category:'Strength',  brand:'Body-Solid',   purchased:'2022-11-01', lastService:'2026-02-20', nextService:'2026-05-20', status:'active',          usage: 85, notes:'All cables intact' },
  { id:5, name:'Leg Press Machine',category:'Strength',  brand:'Leg Press Co', purchased:'2024-01-15', lastService:'2026-04-15', nextService:'2026-07-15', status:'active',          usage: 70, notes:'Good condition' },
  { id:6, name:'Rowing Machine',   category:'Cardio',    brand:'Concept2',     purchased:'2023-03-01', lastService:'2025-12-10', nextService:'2026-03-10', status:'out_of_service',  usage: 0,  notes:'Motor failure — waiting for spare' },
  { id:7, name:'Dumbell Set',      category:'Free Weight',brand:'Iron Co',     purchased:'2022-01-01', lastService:'2026-05-01', nextService:'2026-08-01', status:'active',          usage: 95, notes:'Inspect knurling' },
  { id:8, name:'Elliptical',       category:'Cardio',    brand:'NordicTrack',  purchased:'2023-09-01', lastService:'2026-03-22', nextService:'2026-06-22', status:'active',          usage: 65, notes:'Smooth operation' },
];

const AI_MAINTENANCE = [
  'Treadmill #2 belt worn — order replacement (avg cost ₹3,500). Schedule before weekend rush.',
  'Rowing Machine motor failure. Estimated downtime: 5 days. Alternative: add a Bike for interim.',
  'Cable Crossover is due for service on 2026-05-20. Book mechanic to avoid disruption.',
  'Machines with >85% usage need quarterly service — Treadmill #1 and Dumbbell Set are in this group.',
];

function Badge({ label, color }) {
  return <span style={{ fontSize: 8, fontWeight: 800, letterSpacing: '0.1em', textTransform: 'uppercase', padding: '2px 7px', borderRadius: 5, background: `${color}22`, color, border: `1px solid ${color}44` }}>{label}</span>;
}

export default function EquipmentTab() {
  const [equipment, setEquipment] = useState(INIT_EQUIPMENT);
  const [filter, setFilter]       = useState('all');
  const [addOpen, setAddOpen]     = useState(false);
  const [selected, setSelected]   = useState(null);
  const [aiIdx, setAiIdx]         = useState(0);
  const [form, setForm]           = useState({ name:'', category:'', brand:'', status:'active', notes:'' });

  const filtered = filter === 'all' ? equipment : equipment.filter(e => e.status === filter);

  const addEquipment = () => {
    if (!form.name) return;
    const today = new Date().toISOString().split('T')[0];
    const next  = new Date(); next.setMonth(next.getMonth() + 3);
    setEquipment(e => [...e, { id: Date.now(), ...form, purchased: today, lastService: today, nextService: next.toISOString().split('T')[0], usage: 0 }]);
    setAddOpen(false); setForm({ name:'', category:'', brand:'', status:'active', notes:'' });
  };

  const markServiced = (id) => {
    const today = new Date().toISOString().split('T')[0];
    const next  = new Date(); next.setMonth(next.getMonth() + 3);
    setEquipment(e => e.map(x => x.id === id ? { ...x, lastService: today, nextService: next.toISOString().split('T')[0], status: 'active' } : x));
    setSelected(null);
  };

  const changeStatus = (id, status) => {
    setEquipment(e => e.map(x => x.id === id ? { ...x, status } : x));
    setSelected(null);
  };

  const overdue = equipment.filter(e => new Date(e.nextService) < new Date()).length;

  return (
    <div className="fade-up" style={{ padding: '14px 16px 20px' }}>

      {addOpen && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.75)', zIndex: 100, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
          <div style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 20, padding: 22, width: '100%', maxWidth: 340 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, marginBottom: 14 }}>ADD EQUIPMENT</div>
            {[['name','Machine Name'],['category','Category'],['brand','Brand']].map(([k,l]) => (
              <div key={k} style={{ marginBottom: 10 }}>
                <div style={{ fontSize: 10, color: 'var(--muted)', marginBottom: 4 }}>{l}</div>
                <input className="input-field" value={form[k]} onChange={e => setForm(f => ({ ...f, [k]: e.target.value }))} style={{ padding: '10px 12px', fontSize: 12 }} placeholder={l} />
              </div>
            ))}
            <div style={{ marginBottom: 10 }}>
              <div style={{ fontSize: 10, color: 'var(--muted)', marginBottom: 4 }}>Initial Status</div>
              <select value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value }))} style={{ width: '100%', background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 8, color: 'var(--white)', fontSize: 12, padding: '10px 12px', fontFamily: 'var(--font-body)', outline: 'none' }}>
                {Object.entries(STATUS_LABELS).map(([k,v]) => <option key={k} value={k}>{v}</option>)}
              </select>
            </div>
            <div style={{ marginBottom: 16 }}>
              <div style={{ fontSize: 10, color: 'var(--muted)', marginBottom: 4 }}>Notes</div>
              <input className="input-field" value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} style={{ padding: '10px 12px', fontSize: 12 }} placeholder="Optional notes" />
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <button onClick={() => setAddOpen(false)} className="btn btn-secondary" style={{ fontSize: 12 }}>Cancel</button>
              <button onClick={addEquipment} className="btn btn-primary" style={{ fontSize: 12 }}>Add</button>
            </div>
          </div>
        </div>
      )}

      {selected && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.75)', zIndex: 100, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
          <div style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 20, padding: 22, width: '100%', maxWidth: 340 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 18, marginBottom: 14 }}>{selected.name}</div>
            {[
              ['Category', selected.category],['Brand', selected.brand],
              ['Status', STATUS_LABELS[selected.status]],['Purchased', selected.purchased],
              ['Last Service', selected.lastService],['Next Service', selected.nextService],
              ['Notes', selected.notes],
            ].map(([k,v]) => (
              <div key={k} style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px solid var(--border)', padding: '6px 0', fontSize: 11 }}>
                <span style={{ color: 'var(--muted)' }}>{k}</span>
                <span style={{ color: new Date(selected.nextService) < new Date() && k === 'Next Service' ? 'var(--red)' : 'var(--white)', fontWeight: 600 }}>{v}</span>
              </div>
            ))}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 7, marginTop: 14 }}>
              <button onClick={() => markServiced(selected.id)} style={{ padding: '9px 0', borderRadius: 9, border: 'none', background: 'var(--green)', color: '#fff', fontSize: 10, fontWeight: 700, cursor: 'pointer', fontFamily: 'var(--font-body)' }}>✅ Mark Serviced</button>
              <button onClick={() => changeStatus(selected.id, 'maintenance')} style={{ padding: '9px 0', borderRadius: 9, border: '1px solid var(--amber)', background: 'rgba(245,158,11,0.1)', color: 'var(--amber)', fontSize: 10, fontWeight: 700, cursor: 'pointer', fontFamily: 'var(--font-body)' }}>🔧 Maintenance</button>
              <button onClick={() => changeStatus(selected.id, 'out_of_service')} style={{ padding: '9px 0', borderRadius: 9, border: '1px solid var(--red)', background: 'var(--red-soft)', color: 'var(--red)', fontSize: 10, fontWeight: 700, cursor: 'pointer', fontFamily: 'var(--font-body)' }}>⛔ Out of Service</button>
              <button onClick={() => setSelected(null)} style={{ padding: '9px 0', borderRadius: 9, border: '1px solid var(--border)', background: 'var(--surface)', color: 'var(--muted)', fontSize: 10, fontWeight: 700, cursor: 'pointer', fontFamily: 'var(--font-body)' }}>Close</button>
            </div>
          </div>
        </div>
      )}

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: 22, letterSpacing: '0.04em' }}>
          EQUIP<span style={{ color: '#a855f7' }}>MENT</span>
        </div>
        <button onClick={() => setAddOpen(true)} className="btn btn-primary" style={{ width: 'auto', padding: '7px 14px', fontSize: 11 }}>+ Add</button>
      </div>

      {overdue > 0 && (
        <div style={{ background: 'rgba(255,45,58,0.1)', border: '1px solid rgba(255,45,58,0.3)', borderRadius: 11, padding: '10px 13px', marginBottom: 12, fontSize: 11, color: 'var(--red)', fontWeight: 600 }}>
          ⚠️ {overdue} machine{overdue > 1 ? 's are' : ' is'} overdue for service!
        </div>
      )}

      {/* AI insight */}
      <div style={{ background: 'linear-gradient(135deg,rgba(168,85,247,0.14),rgba(168,85,247,0.04))', border: '1px solid rgba(168,85,247,0.3)', borderRadius: 13, padding: '11px 13px', marginBottom: 14, display: 'flex', gap: 8, alignItems: 'flex-start' }}>
        <span style={{ fontSize: 16 }}>🤖</span>
        <div style={{ flex: 1, fontSize: 10, color: 'var(--muted2)', lineHeight: 1.5 }}>{AI_MAINTENANCE[aiIdx]}</div>
        <button onClick={() => setAiIdx(i => (i+1)%AI_MAINTENANCE.length)} style={{ background: 'none', border: 'none', color: '#a855f7', fontSize: 14, cursor: 'pointer' }}>›</button>
      </div>

      {/* Status summary */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, marginBottom: 14 }}>
        {Object.entries(STATUS_LABELS).map(([k,v]) => (
          <div key={k} style={{ background: 'var(--card)', border: `1px solid ${STATUS_COLORS[k]}44`, borderRadius: 11, padding: '10px 12px', textAlign: 'center' }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, color: STATUS_COLORS[k] }}>
              {equipment.filter(e => e.status === k).length}
            </div>
            <div style={{ fontSize: 8, color: 'var(--muted)', marginTop: 2, textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 700 }}>{v}</div>
          </div>
        ))}
      </div>

      {/* Filter */}
      <div style={{ display: 'flex', gap: 6, marginBottom: 12, flexWrap: 'wrap' }}>
        {[['all','All'], ...Object.entries(STATUS_LABELS)].map(([k,l]) => (
          <button key={k} onClick={() => setFilter(k)} style={{
            padding: '5px 10px', borderRadius: 7, border: `1px solid ${filter === k ? 'var(--red)' : 'var(--border)'}`,
            background: filter === k ? 'var(--red-soft)' : 'var(--surface)',
            color: filter === k ? 'var(--red)' : 'var(--muted)',
            fontSize: 9, fontWeight: 700, cursor: 'pointer', fontFamily: 'var(--font-body)',
          }}>{l}</button>
        ))}
      </div>

      {filtered.map(e => (
        <div key={e.id} onClick={() => setSelected(e)} style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 13, padding: '12px 14px', marginBottom: 9, cursor: 'pointer', transition: 'border-color 0.15s' }}
          onMouseEnter={x => x.currentTarget.style.borderColor = STATUS_COLORS[e.status]}
          onMouseLeave={x => x.currentTarget.style.borderColor = 'var(--border)'}
        >
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10 }}>
            <div style={{ width: 36, height: 36, borderRadius: 10, flexShrink: 0, background: `${STATUS_COLORS[e.status]}18`, border: `1px solid ${STATUS_COLORS[e.status]}44`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18 }}>🏋️</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>{e.name}</div>
              <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap' }}>
                <Badge label={STATUS_LABELS[e.status]} color={STATUS_COLORS[e.status]} />
                <Badge label={e.category} color="var(--blue)" />
                {new Date(e.nextService) < new Date() && <Badge label="OVERDUE" color="var(--red)" />}
              </div>
            </div>
            <div style={{ textAlign: 'right', fontSize: 9, color: 'var(--muted)', flexShrink: 0 }}>
              <div>Next service</div>
              <div style={{ color: new Date(e.nextService) < new Date() ? 'var(--red)' : 'var(--muted2)', fontWeight: 600, marginTop: 2 }}>{e.nextService}</div>
            </div>
          </div>
          {e.notes && <div style={{ fontSize: 9, color: 'var(--muted)', marginTop: 7, paddingLeft: 46 }}>{e.notes}</div>}
        </div>
      ))}
    </div>
  );
}
