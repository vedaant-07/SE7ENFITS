import React, { useState } from 'react';

const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun'];
const INCOME_DATA = [142000, 156000, 148000, 171000, 165000, 186000];
const EXPENSE_DATA = [52000,  61000,  58000,  63000,  69000,  72000];

const TRANSACTIONS = [
  { id:1, type:'income',  category:'Membership', desc:'Annual – Anjali Rao',    amount:1500,  date:'2026-05-26', icon:'💳' },
  { id:2, type:'income',  category:'Membership', desc:'Quarterly – Karan V.',   amount:400,   date:'2026-05-26', icon:'💳' },
  { id:3, type:'expense', category:'Salary',     desc:'Trainer Arjun Mehta',    amount:22000, date:'2026-05-25', icon:'👤' },
  { id:4, type:'expense', category:'Utility',    desc:'Electricity Bill – May', amount:8400,  date:'2026-05-24', icon:'💡' },
  { id:5, type:'income',  category:'Walk-in',    desc:'Day pass × 4',           amount:600,   date:'2026-05-24', icon:'🎟️' },
  { id:6, type:'expense', category:'Equipment',  desc:'Treadmill Belt Repair',  amount:3200,  date:'2026-05-23', icon:'🔧' },
  { id:7, type:'income',  category:'Membership', desc:'Monthly – Arun Sharma',  amount:150,   date:'2026-05-22', icon:'💳' },
  { id:8, type:'expense', category:'Supplies',   desc:'Cleaning + Sanitizer',   amount:1800,  date:'2026-05-21', icon:'🧹' },
];

const EXPENSES_BY_CAT = [
  { cat: 'Salaries',   amount: 45000, color: 'var(--blue)',  pct: 63 },
  { cat: 'Utilities',  amount: 12000, color: 'var(--amber)', pct: 17 },
  { cat: 'Equipment',  amount: 8000,  color: '#a855f7',      pct: 11 },
  { cat: 'Supplies',   amount: 4000,  color: 'var(--green)', pct: 6  },
  { cat: 'Other',      amount: 3000,  color: 'var(--muted)', pct: 4  },
];

const AI_FINANCE = [
  'May revenue up 12.7% MoM. Quarterly plan surge drove ₹28K extra income.',
  'Salary costs at 63% of expenses — consider part-time trainers to reduce fixed costs.',
  'Electricity bill rose 18% in May. Check if equipment is left on overnight.',
  '7 members have dues > 30 days. Projected recovery: ₹18,500 if collected this week.',
];

export default function FinanceTab() {
  const [view, setView] = useState('overview');
  const [addOpen, setAddOpen] = useState(false);
  const [txType, setTxType] = useState('income');
  const [txCat, setTxCat] = useState('');
  const [txDesc, setTxDesc] = useState('');
  const [txAmt, setTxAmt] = useState('');
  const [transactions, setTransactions] = useState(TRANSACTIONS);
  const [aiIdx, setAiIdx] = useState(0);

  const totalIncome  = INCOME_DATA[5];
  const totalExpense = EXPENSE_DATA[5];
  const profit       = totalIncome - totalExpense;
  const margin       = Math.round((profit / totalIncome) * 100);
  const maxBar       = Math.max(...INCOME_DATA, ...EXPENSE_DATA);

  const addTransaction = () => {
    if (!txAmt || !txCat) return;
    setTransactions(t => [{
      id: Date.now(), type: txType, category: txCat, desc: txDesc || txCat,
      amount: Number(txAmt), date: new Date().toISOString().split('T')[0], icon: txType === 'income' ? '💰' : '📤',
    }, ...t]);
    setAddOpen(false); setTxCat(''); setTxDesc(''); setTxAmt('');
  };

  return (
    <div className="fade-up" style={{ padding: '14px 16px 20px' }}>

      {addOpen && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.75)', zIndex: 100, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
          <div style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 20, padding: 22, width: '100%', maxWidth: 340 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, marginBottom: 14 }}>LOG TRANSACTION</div>
            <div style={{ display: 'flex', gap: 8, marginBottom: 14 }}>
              {['income','expense'].map(t => (
                <button key={t} onClick={() => setTxType(t)} style={{
                  flex: 1, padding: '9px 0', borderRadius: 9, border: 'none',
                  background: txType === t ? (t === 'income' ? 'var(--green)' : 'var(--red)') : 'var(--surface)',
                  color: txType === t ? '#fff' : 'var(--muted)',
                  fontFamily: 'var(--font-body)', fontSize: 12, fontWeight: 700, cursor: 'pointer', textTransform: 'capitalize',
                }}>{t === 'income' ? '💰 Income' : '📤 Expense'}</button>
              ))}
            </div>
            {[['txCat','Category', setTxCat, txCat],['txDesc','Description (optional)', setTxDesc, txDesc]].map(([id,l,fn,v]) => (
              <div key={id} style={{ marginBottom: 10 }}>
                <div style={{ fontSize: 10, color: 'var(--muted)', marginBottom: 4 }}>{l}</div>
                <input className="input-field" value={v} onChange={e => fn(e.target.value)} style={{ padding: '10px 12px', fontSize: 12 }} placeholder={l} />
              </div>
            ))}
            <div style={{ marginBottom: 16 }}>
              <div style={{ fontSize: 10, color: 'var(--muted)', marginBottom: 4 }}>Amount (₹)</div>
              <input className="input-field" type="number" value={txAmt} onChange={e => setTxAmt(e.target.value)} style={{ padding: '10px 12px', fontSize: 12 }} placeholder="0" />
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <button onClick={() => setAddOpen(false)} className="btn btn-secondary" style={{ fontSize: 12 }}>Cancel</button>
              <button onClick={addTransaction} className="btn btn-primary" style={{ fontSize: 12 }}>Save</button>
            </div>
          </div>
        </div>
      )}

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: 22, letterSpacing: '0.04em' }}>
          FI<span style={{ color: '#c9a84c' }}>NANCE</span>
        </div>
        <button onClick={() => setAddOpen(true)} className="btn btn-primary" style={{ width: 'auto', padding: '7px 14px', fontSize: 11 }}>+ Log</button>
      </div>

      {/* AI Finance */}
      <div style={{ background: 'linear-gradient(135deg,rgba(168,85,247,0.14),rgba(168,85,247,0.04))', border: '1px solid rgba(168,85,247,0.3)', borderRadius: 13, padding: '11px 13px', marginBottom: 14, display: 'flex', gap: 8, alignItems: 'flex-start' }}>
        <span style={{ fontSize: 16 }}>🤖</span>
        <div style={{ flex: 1, fontSize: 10, color: 'var(--muted2)', lineHeight: 1.5 }}>{AI_FINANCE[aiIdx]}</div>
        <button onClick={() => setAiIdx(i => (i+1)%AI_FINANCE.length)} style={{ background: 'none', border: 'none', color: '#a855f7', fontSize: 14, cursor: 'pointer' }}>›</button>
      </div>

      {/* P&L Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, marginBottom: 14 }}>
        {[
          { label: 'Revenue', value: `₹${(totalIncome/1000).toFixed(0)}K`, color: 'var(--green)' },
          { label: 'Expenses', value: `₹${(totalExpense/1000).toFixed(0)}K`, color: 'var(--red)' },
          { label: `Profit ${margin}%`, value: `₹${(profit/1000).toFixed(0)}K`, color: '#c9a84c' },
        ].map((c, i) => (
          <div key={i} style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 12, padding: '11px 12px' }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, color: c.color, lineHeight: 1 }}>{c.value}</div>
            <div style={{ fontSize: 8, color: 'var(--muted)', marginTop: 3, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.08em' }}>{c.label}</div>
          </div>
        ))}
      </div>

      {/* Revenue vs Expense chart */}
      <div style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 14, padding: '14px 16px', marginBottom: 14 }}>
        <div style={{ fontSize: 10, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.1em', color: 'var(--muted2)', marginBottom: 12 }}>6-Month Trend</div>
        <div style={{ display: 'flex', alignItems: 'flex-end', gap: 4, height: 56 }}>
          {MONTHS.map((m, i) => (
            <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 2, alignItems: 'center' }}>
              <div style={{ width: '100%', display: 'flex', gap: 2, alignItems: 'flex-end', height: 48 }}>
                <div style={{ flex: 1, borderRadius: '2px 2px 0 0', background: 'var(--green)', height: `${(INCOME_DATA[i]/maxBar)*48}px` }} />
                <div style={{ flex: 1, borderRadius: '2px 2px 0 0', background: 'var(--red)', height: `${(EXPENSE_DATA[i]/maxBar)*48}px` }} />
              </div>
              <div style={{ fontSize: 7, color: 'var(--muted)' }}>{m}</div>
            </div>
          ))}
        </div>
        <div style={{ display: 'flex', gap: 12, marginTop: 8 }}>
          <div style={{ display: 'flex', gap: 5, alignItems: 'center', fontSize: 9, color: 'var(--green)' }}><div style={{ width: 8, height: 8, background: 'var(--green)', borderRadius: 2 }} />Income</div>
          <div style={{ display: 'flex', gap: 5, alignItems: 'center', fontSize: 9, color: 'var(--red)' }}><div style={{ width: 8, height: 8, background: 'var(--red)', borderRadius: 2 }} />Expense</div>
        </div>
      </div>

      {/* Expense breakdown */}
      <div style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 14, padding: '14px 16px', marginBottom: 14 }}>
        <div style={{ fontSize: 10, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.1em', color: 'var(--muted2)', marginBottom: 12 }}>Expense Breakdown – May</div>
        {EXPENSES_BY_CAT.map((e, i) => (
          <div key={i} style={{ marginBottom: 9 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 10, marginBottom: 4 }}>
              <span style={{ color: 'var(--white)', fontWeight: 600 }}>{e.cat}</span>
              <span style={{ color: 'var(--muted)' }}>₹{e.amount.toLocaleString()} · {e.pct}%</span>
            </div>
            <div style={{ height: 5, background: 'var(--border)', borderRadius: 3, overflow: 'hidden' }}>
              <div style={{ height: '100%', width: `${e.pct}%`, background: e.color, borderRadius: 3 }} />
            </div>
          </div>
        ))}
      </div>

      {/* Recent transactions */}
      <div style={{ fontSize: 10, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.1em', color: 'var(--muted2)', marginBottom: 10 }}>Recent Transactions</div>
      {transactions.slice(0, 8).map(tx => (
        <div key={tx.id} style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 12, padding: '11px 13px', marginBottom: 8, display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 32, height: 32, borderRadius: 8, background: tx.type === 'income' ? 'rgba(34,197,94,0.1)' : 'rgba(255,45,58,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, flexShrink: 0 }}>{tx.icon}</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 11, fontWeight: 700, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{tx.desc}</div>
            <div style={{ fontSize: 9, color: 'var(--muted2)', marginTop: 1 }}>{tx.category} · {tx.date}</div>
          </div>
          <div style={{ fontSize: 13, fontWeight: 700, color: tx.type === 'income' ? 'var(--green)' : 'var(--red)', flexShrink: 0 }}>
            {tx.type === 'income' ? '+' : '-'}₹{tx.amount.toLocaleString()}
          </div>
        </div>
      ))}
    </div>
  );
}
