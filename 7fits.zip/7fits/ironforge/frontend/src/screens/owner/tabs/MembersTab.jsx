import React, { useState } from 'react';

const PLAN_COLORS = { none: 'var(--muted)', monthly: 'var(--blue)', quarterly: 'var(--amber)', halfyearly: 'var(--red)', annual: '#c9a84c' };
const PLAN_LABELS = { none: 'None', monthly: 'Monthly', quarterly: 'Quarterly', halfyearly: 'Half-Yearly', annual: 'Annual' };
const STATUS_COLORS = { active: 'var(--green)', expiring: 'var(--amber)', expired: 'var(--red)', pending: '#a855f7' };

const MEMBERS = [
  { id: 1, name: 'Rohan Kapoor',   email: 'rohan@gym.com',   phone: '9876543210', plan: 'annual',     status: 'active',   paid: true,  joined: '2026-01-10', expiry: '2027-01-10', streak: 14, attendance: 92 },
  { id: 2, name: 'Priya Mehta',    email: 'priya@gym.com',   phone: '9876543211', plan: 'quarterly',  status: 'expiring', paid: true,  joined: '2026-02-14', expiry: '2026-05-14', streak: 7,  attendance: 78 },
  { id: 3, name: 'Arun Sharma',    email: 'arun@gym.com',    phone: '9876543212', plan: 'monthly',    status: 'active',   paid: false, joined: '2026-03-01', expiry: '2026-06-01', streak: 3,  attendance: 65 },
  { id: 4, name: 'Neha Patel',     email: 'neha@gym.com',    phone: '9876543213', plan: 'halfyearly', status: 'active',   paid: true,  joined: '2026-01-22', expiry: '2026-07-22', streak: 21, attendance: 88 },
  { id: 5, name: 'Vikram Singh',   email: 'vikram@gym.com',  phone: '9876543214', plan: 'none',       status: 'expired',  paid: false, joined: '2026-04-05', expiry: '2026-05-05', streak: 0,  attendance: 40 },
  { id: 6, name: 'Anjali Rao',     email: 'anjali@gym.com',  phone: '9876543215', plan: 'annual',     status: 'active',   paid: true,  joined: '2025-12-01', expiry: '2026-12-01', streak: 30, attendance: 95 },
  { id: 7, name: 'Karan Verma',    email: 'karan@gym.com',   phone: '9876543216', plan: 'monthly',    status: 'expiring', paid: true,  joined: '2026-04-01', expiry: '2026-06-01', streak: 5,  attendance: 70 },
  { id: 8, name: 'Divya Nair',     email: 'divya@gym.com',   phone: '9876543217', plan: 'quarterly',  status: 'active',   paid: false, joined: '2026-02-10', expiry: '2026-05-10', streak: 12, attendance: 82 },
];

const PLAN_PRICES = { none: 0, monthly: 150, quarterly: 400, halfyearly: 800, annual: 1500 };

function Badge({ label, color }) {
  return (
    <span style={{ fontSize: 8, fontWeight: 800, letterSpacing: '0.1em', textTransform: 'uppercase', padding: '2px 7px', borderRadius: 5, background: `${color}22`, color, border: `1px solid ${color}44` }}>
      {label}
    </span>
  );
}

export default function MembersTab() {
  const [members, setMembers] = useState(MEMBERS);
  const [search, setSearch]   = useState('');
  const [filter, setFilter]   = useState('all');
  const [selected, setSelected] = useState(null);
  const [addOpen, setAddOpen] = useState(false);
  const [newMember, setNewMember] = useState({ name: '', email: '', phone: '', plan: 'monthly' });

  const filtered = members.filter(m => {
    const q = search.toLowerCase();
    const matchQ = !q || m.name.toLowerCase().includes(q) || m.email.toLowerCase().includes(q) || m.phone.includes(q);
    const matchF = filter === 'all' || m.status === filter || (filter === 'unpaid' && !m.paid);
    return matchQ && matchF;
  });

  const addMember = () => {
    if (!newMember.name) return;
    const expiry = new Date();
    const days = { monthly: 30, quarterly: 90, halfyearly: 180, annual: 365 };
    expiry.setDate(expiry.getDate() + (days[newMember.plan] || 30));
    setMembers(m => [...m, {
      id: Date.now(), ...newMember, status: 'active', paid: false,
      joined: new Date().toISOString().split('T')[0],
      expiry: expiry.toISOString().split('T')[0],
      streak: 0, attendance: 0,
    }]);
    setAddOpen(false);
    setNewMember({ name: '', email: '', phone: '', plan: 'monthly' });
  };

  const sendReminder = (id) => {
    setMembers(m => m.map(x => x.id === id ? { ...x, _reminded: true } : x));
  };

  return (
    <div className="fade-up" style={{ padding: '14px 16px 20px' }}>

      {/* Add Member Modal */}
      {addOpen && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.75)', zIndex: 100, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
          <div style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 20, padding: 22, width: '100%', maxWidth: 340 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, marginBottom: 16 }}>ADD MEMBER</div>
            {[['name','Full Name'],['email','Email'],['phone','Phone']].map(([k,l]) => (
              <div key={k} style={{ marginBottom: 10 }}>
                <div style={{ fontSize: 10, color: 'var(--muted)', marginBottom: 4 }}>{l}</div>
                <input className="input-field" value={newMember[k]} onChange={e => setNewMember(n => ({ ...n, [k]: e.target.value }))}
                  style={{ padding: '10px 12px', fontSize: 12 }} placeholder={l} />
              </div>
            ))}
            <div style={{ marginBottom: 16 }}>
              <div style={{ fontSize: 10, color: 'var(--muted)', marginBottom: 4 }}>Plan</div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
                {Object.entries(PLAN_LABELS).filter(([k]) => k !== 'none').map(([k, v]) => (
                  <button key={k} onClick={() => setNewMember(n => ({ ...n, plan: k }))} style={{
                    padding: '8px 0', borderRadius: 8,
                    border: `1px solid ${newMember.plan === k ? PLAN_COLORS[k] : 'var(--border)'}`,
                    background: newMember.plan === k ? `${PLAN_COLORS[k]}18` : 'var(--surface)',
                    color: newMember.plan === k ? PLAN_COLORS[k] : 'var(--muted)',
                    fontSize: 10, fontWeight: 700, cursor: 'pointer', fontFamily: 'var(--font-body)',
                  }}>{v}<br /><span style={{ fontSize: 9, opacity: 0.8 }}>₹{PLAN_PRICES[k]}</span></button>
                ))}
              </div>
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <button onClick={() => setAddOpen(false)} className="btn btn-secondary" style={{ fontSize: 12 }}>Cancel</button>
              <button onClick={addMember} className="btn btn-primary" style={{ fontSize: 12 }}>Add Member</button>
            </div>
          </div>
        </div>
      )}

      {/* Member detail modal */}
      {selected && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.75)', zIndex: 100, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
          <div style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 20, padding: 22, width: '100%', maxWidth: 340 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
              <div style={{ width: 46, height: 46, borderRadius: '50%', background: 'linear-gradient(135deg,var(--red),#8b0000)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--font-display)', fontSize: 16 }}>
                {selected.name.split(' ').map(n=>n[0]).join('').slice(0,2)}
              </div>
              <div>
                <div style={{ fontSize: 14, fontWeight: 700 }}>{selected.name}</div>
                <div style={{ fontSize: 10, color: 'var(--muted2)' }}>{selected.phone}</div>
              </div>
            </div>
            {[
              ['Plan', PLAN_LABELS[selected.plan], PLAN_COLORS[selected.plan]],
              ['Status', selected.status, STATUS_COLORS[selected.status]],
              ['Paid', selected.paid ? 'Paid ✓' : 'Due ✗', selected.paid ? 'var(--green)' : 'var(--red)'],
              ['Streak', `${selected.streak} days`, 'var(--amber)'],
              ['Attendance', `${selected.attendance}%`, 'var(--blue)'],
              ['Joined', selected.joined, 'var(--muted2)'],
              ['Expiry', selected.expiry, 'var(--muted2)'],
            ].map(([k,v,c]) => (
              <div key={k} style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px solid var(--border)', padding: '7px 0', fontSize: 12 }}>
                <span style={{ color: 'var(--muted)' }}>{k}</span>
                <span style={{ color: c, fontWeight: 600 }}>{v}</span>
              </div>
            ))}
            <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
              <button onClick={() => { sendReminder(selected.id); setSelected(null); }} style={{ flex: 1, padding: '9px 0', borderRadius: 10, border: '1px solid var(--amber)', background: 'rgba(245,158,11,0.1)', color: 'var(--amber)', fontSize: 11, fontWeight: 700, cursor: 'pointer', fontFamily: 'var(--font-body)' }}>
                📩 Remind
              </button>
              <button onClick={() => { setMembers(m => m.map(x => x.id === selected.id ? { ...x, paid: true } : x)); setSelected(null); }} style={{ flex: 1, padding: '9px 0', borderRadius: 10, border: 'none', background: 'var(--green)', color: '#fff', fontSize: 11, fontWeight: 700, cursor: 'pointer', fontFamily: 'var(--font-body)' }}>
                ✅ Mark Paid
              </button>
              <button onClick={() => setSelected(null)} style={{ flex: 1, padding: '9px 0', borderRadius: 10, border: '1px solid var(--border)', background: 'var(--surface)', color: 'var(--muted)', fontSize: 11, fontWeight: 700, cursor: 'pointer', fontFamily: 'var(--font-body)' }}>
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: 22, letterSpacing: '0.04em' }}>
          MEM<span style={{ color: 'var(--blue)' }}>BERS</span>
        </div>
        <button onClick={() => setAddOpen(true)} className="btn btn-primary" style={{ width: 'auto', padding: '7px 14px', fontSize: 11 }}>+ Add</button>
      </div>

      {/* Filter chips */}
      <div style={{ display: 'flex', gap: 6, marginBottom: 10, flexWrap: 'wrap' }}>
        {[['all','All'],['active','Active'],['expiring','Expiring'],['expired','Expired'],['unpaid','Unpaid']].map(([k,l]) => (
          <button key={k} onClick={() => setFilter(k)} style={{
            padding: '5px 10px', borderRadius: 7, border: `1px solid ${filter === k ? 'var(--red)' : 'var(--border)'}`,
            background: filter === k ? 'var(--red-soft)' : 'var(--surface)',
            color: filter === k ? 'var(--red)' : 'var(--muted)',
            fontSize: 10, fontWeight: 700, cursor: 'pointer', fontFamily: 'var(--font-body)',
          }}>{l}</button>
        ))}
      </div>

      <input className="input-field" placeholder="🔍 Search name, email, phone…" value={search} onChange={e => setSearch(e.target.value)}
        style={{ marginBottom: 10, fontSize: 12, padding: '10px 12px' }} />

      <div style={{ fontSize: 10, color: 'var(--muted)', marginBottom: 10 }}>{filtered.length} member{filtered.length !== 1 ? 's' : ''}</div>

      {filtered.map(m => (
        <div key={m.id} onClick={() => setSelected(m)} style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 13, padding: '12px 14px', marginBottom: 9, cursor: 'pointer', transition: 'border-color 0.15s' }}
          onMouseEnter={e => e.currentTarget.style.borderColor = 'var(--red)'}
          onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--border)'}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 36, height: 36, borderRadius: '50%', flexShrink: 0, background: 'linear-gradient(135deg,var(--red),#8b0000)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--font-display)', fontSize: 12 }}>
              {m.name.split(' ').map(n=>n[0]).join('').slice(0,2)}
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 12, fontWeight: 700, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{m.name}</div>
              <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap', marginTop: 4 }}>
                <Badge label={PLAN_LABELS[m.plan]} color={PLAN_COLORS[m.plan] || 'var(--muted)'} />
                <Badge label={m.status} color={STATUS_COLORS[m.status]} />
                {!m.paid && <Badge label="DUE" color="var(--red)" />}
                {m._reminded && <Badge label="Reminded" color="var(--green)" />}
              </div>
            </div>
            <div style={{ fontSize: 9, color: 'var(--muted)', flexShrink: 0, textAlign: 'right' }}>
              <div>Exp {m.expiry}</div>
              <div style={{ color: 'var(--amber)' }}>🔥 {m.streak}d</div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
