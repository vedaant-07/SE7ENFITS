import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import OverviewTab from './tabs/OverviewTab';
import MembersTab from './tabs/MembersTab';
import FinanceTab from './tabs/FinanceTab';
import EquipmentTab from './tabs/EquipmentTab';
import StaffTab from './tabs/StaffTab';
import NotificationsTab from './tabs/NotificationsTab';
import ReportsTab from './tabs/ReportsTab';

const TABS = [
  { id: 'overview',       icon: '📊', label: 'Overview' },
  { id: 'members',        icon: '👥', label: 'Members' },
  { id: 'finance',        icon: '💰', label: 'Finance' },
  { id: 'equipment',      icon: '🏋️', label: 'Equipment' },
  { id: 'staff',          icon: '👨‍💼', label: 'Staff' },
  { id: 'notifications',  icon: '🔔', label: 'Alerts' },
  { id: 'reports',        icon: '📈', label: 'Reports' },
];

export default function OwnerDashboard() {
  const { user, logout } = useAuth();
  const [tab, setTab] = useState('overview');
  const [menuOpen, setMenuOpen] = useState(false);

  const current = TABS.find(t => t.id === tab);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Top bar */}
      <div style={{
        padding: '14px 18px 12px',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        borderBottom: '1px solid var(--border)',
        background: 'var(--surface)',
        flexShrink: 0,
      }}>
        <div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, letterSpacing: '0.06em', lineHeight: 1 }}>
            <span style={{ color: 'var(--red)' }}>IRON</span>FORGE
          </div>
          <div style={{ fontSize: 9, color: 'var(--muted)', letterSpacing: '0.15em', textTransform: 'uppercase', marginTop: 1 }}>
            Owner Dashboard
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontSize: 11, fontWeight: 700 }}>{user?.name}</div>
            <div style={{ fontSize: 9, color: 'var(--red)', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Owner</div>
          </div>
          <button onClick={logout} style={{
            background: 'var(--card)', border: '1px solid var(--border)',
            color: 'var(--muted)', fontSize: 10, fontWeight: 700,
            padding: '6px 10px', borderRadius: 8, cursor: 'pointer', fontFamily: 'var(--font-body)',
          }}>Out</button>
        </div>
      </div>

      {/* Tab scroll bar */}
      <div style={{
        display: 'flex', overflowX: 'auto', flexShrink: 0,
        background: 'var(--bg)', borderBottom: '1px solid var(--border)',
        scrollbarWidth: 'none',
      }}>
        {TABS.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{
            flexShrink: 0,
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2,
            padding: '8px 14px 7px', border: 'none',
            background: 'transparent', cursor: 'pointer',
            borderBottom: `2px solid ${tab === t.id ? 'var(--red)' : 'transparent'}`,
            transition: 'all 0.2s',
            fontFamily: 'var(--font-body)',
          }}>
            <span style={{ fontSize: 15 }}>{t.icon}</span>
            <span style={{ fontSize: 8, fontWeight: 800, letterSpacing: '0.1em', textTransform: 'uppercase', color: tab === t.id ? 'var(--red)' : 'var(--muted)' }}>
              {t.label}
            </span>
          </button>
        ))}
      </div>

      {/* Content */}
      <div style={{ flex: 1, overflowY: 'auto', overflowX: 'hidden', scrollbarWidth: 'none' }}>
        {tab === 'overview'      && <OverviewTab setTab={setTab} />}
        {tab === 'members'       && <MembersTab />}
        {tab === 'finance'       && <FinanceTab />}
        {tab === 'equipment'     && <EquipmentTab />}
        {tab === 'staff'         && <StaffTab />}
        {tab === 'notifications' && <NotificationsTab />}
        {tab === 'reports'       && <ReportsTab />}
      </div>
    </div>
  );
}
