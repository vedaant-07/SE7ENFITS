import React from 'react';

export default function StatusBar() {
  const now = new Date();
  const time = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });

  return (
    <div style={{
      height: 44,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 20px',
      background: 'var(--bg)',
      flexShrink: 0,
    }}>
      <span style={{ fontSize: 13, fontWeight: 700, letterSpacing: '0.02em' }}>{time}</span>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <svg width="16" height="12" viewBox="0 0 16 12" fill="none">
          <rect x="0" y="3" width="3" height="9" rx="1" fill="currentColor" opacity="0.4"/>
          <rect x="4.5" y="2" width="3" height="10" rx="1" fill="currentColor" opacity="0.6"/>
          <rect x="9" y="0" width="3" height="12" rx="1" fill="currentColor" opacity="0.8"/>
          <rect x="13.5" y="0" width="2.5" height="12" rx="1" fill="currentColor"/>
        </svg>
        <svg width="16" height="12" viewBox="0 0 24 24" fill="currentColor">
          <path d="M1.371 5.912C5.473 2.212 10.992.667 16.379 1.51c5.387.843 9.945 3.9 12.73 8.396l-2.13 1.313c-2.41-3.912-6.379-6.54-11.066-7.283-4.688-.743-9.459.606-13.01 3.715L1.37 5.912z"/>
          <path d="M4.477 9.648c2.81-2.41 6.574-3.57 10.328-3.187 3.754.383 7.061 2.237 9.248 5.133l-2.02 1.465c-1.825-2.377-4.57-3.909-7.657-4.233-3.087-.324-6.1.62-8.367 2.578L4.478 9.648z"/>
          <path d="M7.617 13.41c1.755-1.506 4.069-2.22 6.369-1.945 2.3.274 4.351 1.497 5.665 3.385l-2.025 1.463c-.97-1.347-2.447-2.19-4.09-2.387-1.644-.196-3.266.288-4.535 1.358L7.617 13.41z"/>
          <circle cx="12" cy="20" r="2"/>
        </svg>
        <div style={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          <div style={{ width: 22, height: 11, border: '1.5px solid var(--muted2)', borderRadius: 3, padding: '1.5px 2px', display: 'flex', alignItems: 'center' }}>
            <div style={{ width: '70%', height: '100%', background: 'var(--green)', borderRadius: 1.5 }} />
          </div>
          <div style={{ width: 2, height: 5, background: 'var(--muted2)', borderRadius: 1 }} />
        </div>
      </div>
    </div>
  );
}
