import React, { useEffect } from 'react';

export default function Toast({ message, type = 'success', onClose }) {
  useEffect(() => {
    const t = setTimeout(onClose, 2800);
    return () => clearTimeout(t);
  }, [onClose]);

  const color = type === 'error' ? 'var(--red)' : 'var(--green)';

  return (
    <div style={{
      position: 'fixed',
      bottom: 90,
      left: '50%',
      transform: 'translateX(-50%)',
      background: 'var(--card)',
      border: `1px solid ${color}44`,
      borderRadius: 12,
      padding: '10px 18px',
      fontSize: 13,
      fontWeight: 600,
      color,
      zIndex: 999,
      whiteSpace: 'nowrap',
      boxShadow: '0 8px 24px rgba(0,0,0,0.4)',
      animation: 'fadeUp 0.25s ease',
    }}>
      {type === 'success' ? '✓ ' : '✕ '}{message}
    </div>
  );
}
