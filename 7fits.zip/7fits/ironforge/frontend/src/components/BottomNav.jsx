import React from 'react';

const TABS = [
  { id: 'home',      icon: '🏠', label: 'Home' },
  { id: 'workouts',  icon: '💪', label: 'Train' },
  { id: 'diet',      icon: '🥗', label: 'Diet' },
  { id: 'analytics', icon: '📊', label: 'Stats' },
  { id: 'plans',     icon: '⭐', label: 'Plans' },
];

export default function BottomNav({ activeTab, setActiveTab }) {
  return (
    <div style={{
      height: 70,
      display: 'flex',
      alignItems: 'center',
      background: 'var(--surface)',
      borderTop: '1px solid var(--border)',
      flexShrink: 0,
    }}>
      {TABS.map(t => {
        const active = activeTab === t.id;
        return (
          <div
            key={t.id}
            onClick={() => setActiveTab(t.id)}
            style={{
              flex: 1,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: 3,
              cursor: 'pointer',
              padding: '8px 0',
              transition: 'all 0.2s',
            }}
          >
            <span style={{ fontSize: 20, filter: active ? 'none' : 'grayscale(1) opacity(0.4)' }}>{t.icon}</span>
            <span style={{
              fontSize: 9,
              fontWeight: 700,
              letterSpacing: '0.1em',
              textTransform: 'uppercase',
              color: active ? 'var(--red)' : 'var(--muted)',
            }}>{t.label}</span>
            {active && (
              <div style={{ width: 4, height: 4, borderRadius: '50%', background: 'var(--red)', marginTop: -2 }} />
            )}
          </div>
        );
      })}
    </div>
  );
}
