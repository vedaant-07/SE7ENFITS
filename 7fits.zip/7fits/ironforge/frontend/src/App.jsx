import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import AuthScreen from './screens/AuthScreen';
import HomeScreen from './screens/HomeScreen';
import WorkoutsScreen from './screens/WorkoutsScreen';
import DietScreen from './screens/DietScreen';
import AnalyticsScreen from './screens/AnalyticsScreen';
import PlansScreen from './screens/PlansScreen';
import AdminScreen from './screens/AdminScreen';
import OwnerDashboard from './screens/owner/OwnerDashboard';
import StatusBar from './components/StatusBar';
import BottomNav from './components/BottomNav';

function Shell() {
  const { user, loading } = useAuth();
  const [activeTab, setActiveTab] = useState('home');

  if (loading) {
    return (
      <div className="phone-shell" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div className="spinner" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="phone-shell">
        <StatusBar />
        <AuthScreen />
      </div>
    );
  }

  if (user.role === 'admin' || user.role === 'owner') {
    return (
      <div className="phone-shell">
        <StatusBar />
        <div className="screen-body" style={{ paddingBottom: 0 }}>
          <OwnerDashboard />
        </div>
      </div>
    );
  }

  const screens = {
    home:      <HomeScreen setActiveTab={setActiveTab} />,
    workouts:  <WorkoutsScreen />,
    diet:      <DietScreen />,
    analytics: <AnalyticsScreen />,
    plans:     <PlansScreen />,
  };

  return (
    <div className="phone-shell">
      <StatusBar />
      <div className="screen-body">
        {screens[activeTab]}
      </div>
      <BottomNav activeTab={activeTab} setActiveTab={setActiveTab} />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <Shell />
    </AuthProvider>
  );
}
